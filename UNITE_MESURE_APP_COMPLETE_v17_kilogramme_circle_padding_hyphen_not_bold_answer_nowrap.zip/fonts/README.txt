Dépose ici tes polices (.ttf/.otf) si tu veux embarquer des fonts custom.
Exemples: STIXTwoText-Regular.ttf, STIXTwoText-Bold.ttf, etc.
